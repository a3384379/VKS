# 知境 VKS 功能与来源

此资料由当前工作区的实际源码与OpenAPI生成。关系为人工编排的候选，不代表真实运行观察；所有功能细节以引用修订为准。

## 项目与模块

创建项目及业务模块，成员权限决定可见资料。 服务方法 `Service.create_project`；接口声明 `POST /api/v1/projects`。

## 资料接入

只读采集并导入固定资料，检查摘要和定位，不执行仓库脚本。 服务方法 `Service.import_bundle`；接口声明 `POST /api/v1/projects/{pid}/imports`。

## 场景与采集

场景修订与有限分支独立保存；采集必须固定环境、合成数据和审批。 服务方法 `ScenarioService.create`；接口声明 `POST /api/v1/projects/{pid}/scenarios`。

## 文档与审核

编辑生成新修订，章节锁和文档人员审核参与发布检查。 服务方法 `Service.save_document`；接口声明 `PUT /api/v1/documents/{eid}/draft`。

## 关系审核

人工审核和证据有效性分别保存，机器只可提议候选。 服务方法 `Service.review_relation`；接口声明 `POST /api/v1/relations/{rid}/review`。

## 知识探索

按同一知识基线和当前权限读取局部图谱。 服务方法 `Service.graph`；接口声明 `GET /api/v1/entities/{eid}/relations`。

## 版本发布

发布需要预检、人员会话确认和固定manifest；旧修订保持可读。 服务方法 `Service.publish`；接口声明 `POST /api/v1/release-candidates/{cid}/publish`。

## MCP客户端

专用客户端凭证按项目与scope授权，服务器逐次重新校验。 服务方法 `Service.create_token`；接口声明 `POST /api/v1/projects/{pid}/tokens`。

